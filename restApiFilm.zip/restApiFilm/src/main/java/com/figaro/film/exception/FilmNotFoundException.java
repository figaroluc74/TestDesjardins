package com.figaro.film.exception;

import java.text.MessageFormat;

@SuppressWarnings("serial")
public class FilmNotFoundException extends RuntimeException {
    
	public FilmNotFoundException(final Long id){
        super(MessageFormat.format("Le film dont l'id est : {0} n'a pas été trouvé", id));
    }
}
