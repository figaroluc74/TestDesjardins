package com.figaro.film.mapper;

import org.mapstruct.Mapper;

import com.figaro.film.model.Film;
import com.figaro.film.model.dto.FilmDto;

@Mapper
public interface FilmMapper {

	Film filmDtoToFilm(FilmDto filmDto);
	FilmDto filmToFilmDto(Film film);
}
