package com.figaro.film;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RestApiFilmApplication {

	public static void main(String[] args) {
		SpringApplication.run(RestApiFilmApplication.class, args);
	}

}
