package com.figaro.film.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.figaro.film.exception.FilmNotFoundException;
import com.figaro.film.model.Film;
import com.figaro.film.repository.FilmRepository;

@Service
public class FilmServiceImpl implements FilmService{
	
	private final FilmRepository filmRepository;

	@Autowired
	public FilmServiceImpl(FilmRepository filmRepository) {
		this.filmRepository = filmRepository;
	}

	public Film addFilm(Film film) {
		return filmRepository.save(film);
	}	

	public Film getFilmById(Long id) {
		return filmRepository.findById(id).orElseThrow(() -> new FilmNotFoundException(id));
	}
}
