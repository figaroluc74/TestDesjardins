package com.figaro.film.service;

import com.figaro.film.model.Film;

public interface FilmService {
	
	Film addFilm(Film film);
	Film getFilmById(Long id); 
}
