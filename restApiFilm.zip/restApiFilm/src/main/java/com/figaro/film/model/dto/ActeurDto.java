package com.figaro.film.model.dto;

import lombok.Data;

@Data
public class ActeurDto {

	private Long id;
	private String nom;
	private String prenom;	
}
