package com.figaro.film.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.figaro.film.mapper.FilmMapperImpl;
import com.figaro.film.model.Film;
import com.figaro.film.model.dto.FilmDto;
import com.figaro.film.service.FilmServiceImpl;

import lombok.extern.slf4j.Slf4j;

@RestController
@RequestMapping("/api")
@Slf4j
public class FilmController {
	
	private final FilmServiceImpl filmService;
	private final FilmMapperImpl mapper;

	@Autowired
	public FilmController(FilmServiceImpl filmService, FilmMapperImpl mapper) {
		this.filmService = filmService;
		this.mapper = mapper;
	}

	@PostMapping(value = "/film")
	public ResponseEntity<FilmDto> addFilm(@RequestBody final FilmDto filmDto) {
		Film filmCreated = filmService.addFilm(mapper.filmDtoToFilm(filmDto));
		
		log.info("Ajout d'un nouveau film dont l'ID est : " + filmCreated.getId());
		
		return new ResponseEntity<>(mapper.filmToFilmDto(filmCreated), HttpStatus.CREATED);
	}

	@GetMapping(value = "/film/{id}")
	public ResponseEntity<FilmDto> getFilm(@PathVariable final Long id) {
		Film film = filmService.getFilmById(id);
		
		log.info("Recherche du film ayant l'ID : " + film.getId());
		
		return new ResponseEntity<>(mapper.filmToFilmDto(film), HttpStatus.OK);
	}
}
