package com.figaro.film.mapper;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

import com.figaro.film.model.Acteur;
import com.figaro.film.model.Film;
import com.figaro.film.model.dto.ActeurDto;
import com.figaro.film.model.dto.FilmDto;

/**  
 * Cette classe transforme un Film en un FilmDto et vice versa  
 */

@Component
public class FilmMapperImpl implements FilmMapper{
	
	@Override
    public Film filmDtoToFilm(FilmDto filmDto) {
		
		if (filmDto == null ) {
            return null;
        }
		
		Film film = new Film();
		film.setId(filmDto.getId());
		film.setTitre(filmDto.getTitre());
		film.setDescription(filmDto.getDescription());
		
		List<Acteur> acteurs = new ArrayList<Acteur>();
		Acteur acteur = null;
		
		for(ActeurDto acd : filmDto.getActeurs()) {
			acteur = new Acteur();
			acteur.setId(acd.getId());
			acteur.setNom(acd.getNom());
			acteur.setPrenom(acd.getPrenom());
			
			acteurs.add(acteur);
		}
		
		film.setActeurs(acteurs);
		
		return film;
	}
	
	@Override
    public FilmDto filmToFilmDto(Film film) {
		
		if (film == null ) {
            return null;
        }
		
		FilmDto filmDto = new FilmDto();
		filmDto.setId(film.getId());
		filmDto.setTitre(film.getTitre());
		filmDto.setDescription(film.getDescription());
		
		List<ActeurDto> acteursDto = new ArrayList<ActeurDto>();
		ActeurDto acteurDto = null;
		
		for(Acteur ac : film.getActeurs()) {
			acteurDto = new ActeurDto();
			acteurDto.setId(ac.getId());
			acteurDto.setNom(ac.getNom());
			acteurDto.setPrenom(ac.getPrenom());
			
			acteursDto.add(acteurDto);
		}
		
		filmDto.setActeurs(acteursDto);
		
		return filmDto;
	}
}
