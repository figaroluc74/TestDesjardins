package com.figaro.film;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestApiFilmApplicationTests {

	@Test
	void contextLoads() {
	}

}
